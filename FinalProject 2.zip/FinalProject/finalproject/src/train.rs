// This module trains a machine learning model using random forest regression to predict the most likely national ranking of a college that a student can get into based on their high school GPA and SAT score.
use smartcore::{
    ensemble::random_forest_regressor::RandomForestRegressor,
    linalg::basic::matrix::DenseMatrix,
    preprocessing::numerical::StandardScaler,
    api::*,
};
use csv::Reader;
use std::path::Path;


// Trains a random forest regressor model on the training dataset. It returns a tuple containing the trained model and a standard scalar for normalization.
// train_path: The file path to the training dataset
// Returns: A tuple containing the trained model and a standard scalar
pub fn train_model(
    train_path: &Path
) -> Result<(RandomForestRegressor<f64, f64, DenseMatrix<f64>, Vec<f64>>, StandardScaler<f64>), Box<dyn std::error::Error>> {
    let mut reader = Reader::from_path(train_path)?;
    let mut features = Vec::new();
    let mut targets = Vec::new(); 

    // Iterate over the CSV file and extract features and targets
    for result in reader.records() {
        let record = result?;
        if let (Ok(gpa), Ok(sat), Ok(ranking)) = (
            record[1].parse::<f64>(),
            record[2].parse::<f64>(),
            record[3].parse::<f64>(),
        ) {
            features.push(vec![gpa, sat]);
            targets.push(ranking);
        } else {
            println!("⚠️ Skipping invalid record: {:?}", record);
        }
    }

    // Convert features and targets to matrices
    let x = DenseMatrix::from_2d_vec(&features);
    let y = targets;


    // Normalize the features
    let scaler = StandardScaler::fit(&x, Default::default())?;
    let x_normalized = scaler.transform(&x)?;    

    
    // Trains a random forest regressor model on the scaled and normalized data
    let model = RandomForestRegressor::fit(
        &x_normalized,
        &y,
        Default::default()
    )?;

    Ok((model, scaler))
}

