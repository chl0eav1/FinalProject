// This module trains a random forest regressor on the training data, evaluates the accuracy on the test data, and makes predictions about rank and suggestions for universities around that rank.
use std::path::Path;
use smartcore::linalg::basic::matrix::DenseMatrix;
use rand::seq::SliceRandom;
use smartcore::api::*;
use std::io;
mod train;
mod test;


// Trains a model, takes user input, makes a prediction, and suggests universities based on the prediction.
// Inputs:
// train_path: The file path to the training dataset
// university_path: The file path to the university dataset
fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Define file paths
    let train_path = Path::new("/Users/chloe/Desktop/FinalProject/finalproject/data/train_studentstats.csv");
    let university_path = Path::new("/Users/chloe/Desktop/FinalProject/finalproject/data/schoolstats.csv");

    println!("Training model...");
    let (model, scaler) = train::train_model(train_path)?;
    

    // Get user input
    println!("Enter your GPA (e.g. 3.9): ");
    let mut gpa_input = String::new();
    io::stdin().read_line(&mut gpa_input).expect("Failed to read line");
    let sample_gpa: f64 = gpa_input.trim().parse().expect("Please type a number!");
    
    println!("Enter your SAT score (e.g. 1590): ");
    let mut sat_input = String::new();
    io::stdin().read_line(&mut sat_input).expect("Failed to read line");
    let sample_sat: f64 = sat_input.trim().parse().expect("Please type a number!");
    

    // Use model to make prediction
    let sample_features = vec![sample_gpa, sample_sat];
    let sample_matrix = DenseMatrix::from_2d_vec(&vec![sample_features]);
    let normalized_sample = scaler.transform(&sample_matrix)?;
    let prediction = model.predict(&normalized_sample)?[0];
    
    println!("\nSample Prediction:");
    println!("   GPA: {:.1}, SAT: {:.0} => Predicted Rank: {:.1}", sample_gpa, sample_sat, prediction);
    
   
    // Use prediction to suggest universities
    let universities = load_universities(university_path)?;
    let suggestions = suggest_schools(&universities, prediction);
    
    println!("\nRecommended Universities:");
    if suggestions.is_empty() {
        println!("   It is not likely that you will get into a top 200 University");
    } else {
        for (i, (name, rank)) in suggestions.iter().enumerate() {
            println!("   {}. {} (Rank: {})", i+1, name, rank);
        }
    }

    Ok(())
}


// Loads universities from a CSV file and returns a vector of tuples containing their names and ranks
// Inputs:
// path: The file path to the CSV file
// Outputs:
// universities: A vector of tuples containing university names and ranks
fn load_universities(path: &Path) -> Result<Vec<(String, usize)>, Box<dyn std::error::Error>> {
    let mut reader = csv::Reader::from_path(path)?;
    let mut universities = Vec::new();
    
    // Iterate over the CSV file and extract university names and ranks
    for result in reader.records() {
        let record = result?;
        if record.len() >= 2 {
            let name = record[0].to_string();
            if let Ok(rank) = record[1].parse::<usize>() {
                universities.push((name, rank));
            }
        }
    }
    
    Ok(universities)
}


// Returns a vector of universities that are within the predicted rank range
// Inputs:
// universities: A vector of tuples containing university names and ranks
// predicted_rank: The predicted rank
// Outputs:
// suggestions: A vector of tuples containing university names and ranks
fn suggest_schools(universities: &[(String, usize)], predicted_rank: f64) -> Vec<&(String, usize)> {
    // Determine the predicted rank range
    let (min_rank, max_rank) = if predicted_rank <= 50.0 {
        (1, 50)
    } else if predicted_rank <= 100.0 {
        (51, 100)
    } else if predicted_rank <= 150.0 {
        (101, 150)
    } else if predicted_rank <= 200.0 {
        (151, 200)
    } else {
        return Vec::new();
    };

    // Filter universities within the predicted rank range
    let mut candidates: Vec<_> = universities
        .iter()
        .filter(|(_, rank)| *rank >= min_rank && *rank <= max_rank)
        .collect();
    
    let mut rng = rand::thread_rng();
    candidates.shuffle(&mut rng);
    candidates.truncate(5);
    candidates
}


#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_train_model_accuracy() {
        let train_path = Path::new("/Users/chloe/Desktop/FinalProject/finalproject/data/train_studentstats.csv");
        let test_path = Path::new("/Users/chloe/Desktop/FinalProject/finalproject/data/test_studentstats.csv");

        let (model, scaler) = train::train_model(train_path).unwrap();

        let metrics = test::evaluate_model(&model, test_path, &scaler).unwrap();
        println!("Model Accuracy (R² score): {:.2}%", metrics.r2 * 100.0);

        assert!(metrics.r2 > 0.1);
    }

    #[test]
    fn test_load_universities() {
        let university_path = Path::new("/Users/chloe/Desktop/FinalProject/finalproject/data/schoolstats.csv");
        let universities = load_universities(university_path).unwrap();
        assert!(!universities.is_empty());
    }

    #[test]
    fn test_suggest_schools() {
        let universities = vec![("University A".to_string(), 1), ("University B".to_string(), 2)];
        let predicted_rank = 1.5;
        let suggestions = suggest_schools(&universities, predicted_rank);
        assert!(!suggestions.is_empty());
    }
}