// This module assesses the accuracy of the model trained using random forest regression.
use smartcore::{
    ensemble::random_forest_regressor::RandomForestRegressor,
    linalg::basic::matrix::DenseMatrix,
    preprocessing::numerical::StandardScaler,
    metrics::{mean_absolute_error, mean_squared_error, r2},
    api::*,
};
use csv::Reader;
use std::path::Path;


// A struct to hold metrics calculated during model evaluation
#[allow(dead_code)]
pub struct ModelMetrics {
    pub mae: f64,
    pub rmse: f64,
    pub r2: f64,
    #[allow(dead_code)]
    pub predictions: Vec<(f64, f64)>,
}


// Evaluates the performance of the trained random forest regressor model on the test dataset. It uses the model to make predictions on the test data and calculates metrics such as R² score, mean absolute error, and root mean squared error to assess the model's performance.
// Inputs: 
// model: The trained random forest regressor model
// test_path: The file path to the test dataset
// scaler: The standard scaler used to normalize the features
// Outputs:
// metrics: A struct containing the calculated metrics
#[allow(dead_code)]
pub fn evaluate_model(
    model: &RandomForestRegressor<f64, f64, DenseMatrix<f64>, Vec<f64>>,
    test_path: &Path,
    scaler: &StandardScaler<f64>,
) -> Result<ModelMetrics, Box<dyn std::error::Error>> {


    let mut reader = Reader::from_path(test_path)?;
    let mut features = Vec::new();
    let mut targets = Vec::new();


    // Iterate over the CSV file and extract features and targets
    for result in reader.records() {
        let record = result?;
        if let (Ok(gpa), Ok(sat), Ok(ranking)) = (
            record[1].parse::<f64>(),
            record[2].parse::<f64>(),
            record[3].parse::<f64>(),
        ) {
            features.push(vec![gpa, sat]);
            targets.push(ranking);
        } else {
            println!("⚠️ Skipping invalid record: {:?}", record);
        }
    }

    // Convert features and targets to matrices
    let x = DenseMatrix::from_2d_vec(&features);
    let x_normalized = scaler.transform(&x)?;
    let predictions = model.predict(&x_normalized)?;

    
    // Calculate metrics
    Ok(ModelMetrics {
        mae: mean_absolute_error(&targets, &predictions),
        rmse: mean_squared_error(&targets, &predictions).sqrt(),
        r2: r2(&targets, &predictions),
        predictions: targets.iter()
            .zip(predictions.iter())
            .map(|(&a, &p)| (a, p))
            .collect(),
    })
}